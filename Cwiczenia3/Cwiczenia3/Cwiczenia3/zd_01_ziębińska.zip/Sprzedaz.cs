﻿namespace Cwiczenia3
{
    public class Sprzedaz
    {
        #region Pola
        private double _cena;
        private int _szt;         
        private bool _upust;
        #endregion

        #region Właściwości
        public double Wartosc
                {
                    get { return _szt * _cena;}
                    private set { }
                }

                public string Upust
                {
                    get
                    {
                        if (_upust)
                            return "udzielono upustu";
                        else
                            return "nie udzielono upustu";
                    } 
                    private set {}
                }
        #endregion

        #region Konstruktory

        public Sprzedaz(double cena, int szt, bool upust)
        {
            _cena = cena;
            _szt = szt;
            _upust = upust;
        }
        #endregion

        #region Metody

        public override string ToString()
        {
            return $"Wartość sprzedaży: {Wartosc}, {Upust}";
        }

        #endregion
    }
}