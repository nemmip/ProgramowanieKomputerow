﻿using System;

namespace Cwiczenia3
{
    class Program
    {
        static void Main(string[] args)
        {
            Sprzedaz p1 = new Sprzedaz(12.5, 15, true);
            Sprzedaz p2 = new Sprzedaz(55.99, 7, false);
            Console.WriteLine(p1.ToString());
            Console.WriteLine(p2.ToString());
            Console.ReadLine();

        }
    }
}