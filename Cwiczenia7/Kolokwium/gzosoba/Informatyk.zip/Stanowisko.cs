﻿namespace gzosoba
{
    public enum Stanowisko
    {
        informatyk,
        kierownik
    }
}